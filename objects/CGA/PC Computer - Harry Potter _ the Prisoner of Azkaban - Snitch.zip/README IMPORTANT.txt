date: 2016

these fbx files build version is 2016 (fbx 7.1), it is reccomeneded you have the latest update of your 3D software.
though these files are known to open in many common 3d softwares such as blender nomatter the version, this does apply for cinema4d.
make sure you have installed cinema4d r17 and check for updates in order for compatibility for the 2016 fbx generation. or cinema4d r18 and above

though this readme will most likely expire after 2018 or later as time would have passed since this file was uploaded, hopefully by then
you wont have an outdated 3D software.

thank you :)

-NavyFoxKid